# KIIT KSAC Voting Platform

This is a console-based voting system created for educational and practice purposes only. It simulates the election process for the positions of Coordinator and Assistant Coordinator under the KIIT Student Activity Center (KSAC) at KIIT University.

## Features

- Candidates A to E: Coordinator
- Candidates F to J: Assistant Coordinator
- One vote per user using unique voter ID
- Prevents double voting
- Displays vote count
- Shows the elected candidates with the highest votes

## Instructions

### Compile

```bash
gcc kiit_ksac_voting.c -o voting
```

### Run

```bash
./voting
```

## Disclaimer

This project is a **simulation created solely for learning and practice**. It is **not used in real elections** or any official capacity. All data and structure are purely fictional.
