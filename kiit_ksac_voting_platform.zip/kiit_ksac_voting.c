#include <stdio.h>
#include <string.h>

#define MAX_VOTERS 100

int votes[10] = {0};
int totalVoters = 0;
int hasVoted[MAX_VOTERS] = {0};

void displayMainMenu() {
    printf("\n--- KIIT KSAC Voting Platform ---\n");
    printf("1. Cast Vote\n");
    printf("2. View Vote Count\n");
    printf("3. Display Elected Candidates\n");
    printf("4. Exit\n");
    printf("Enter your choice: ");
}

void displayCandidates() {
    printf("\n--- Candidates List ---\n");
    printf("Coordinator Candidates (A-E):\n");
    for (char c = 'A'; c <= 'E'; c++) {
        printf("%c. Candidate %c\n", c, c);
    }
    printf("Asst. Coordinator Candidates (F-J):\n");
    for (char c = 'F'; c <= 'J'; c++) {
        printf("%c. Candidate %c\n", c, c);
    }
}

void castVote() {
    int voterID;
    char vote;
    printf("\nEnter your Voter ID (0 - %d): ", MAX_VOTERS - 1);
    scanf("%d", &voterID);

    if (voterID < 0 || voterID >= MAX_VOTERS) {
        printf("Invalid Voter ID.\n");
        return;
    }

    if (hasVoted[voterID]) {
        printf("You have already cast your vote.\n");
        return;
    }

    displayCandidates();
    printf("Enter your vote (A-J): ");
    scanf(" %c", &vote);

    if (vote >= 'A' && vote <= 'J') {
        votes[vote - 'A']++;
        hasVoted[voterID] = 1;
        totalVoters++;
        printf("Vote successfully casted for Candidate %c.\n", vote);
    } else {
        printf("Invalid candidate selection.\n");
    }
}

void viewVoteCount() {
    printf("\n--- Vote Count ---\n");
    for (char c = 'A'; c <= 'J'; c++) {
        printf("Candidate %c: %d votes\n", c, votes[c - 'A']);
    }
}

void displayWinners() {
    int maxCoordVotes = -1, maxAsstCoordVotes = -1;
    char electedCoord = 'A', electedAsstCoord = 'F';

    for (int i = 0; i <= 4; i++) {
        if (votes[i] > maxCoordVotes) {
            maxCoordVotes = votes[i];
            electedCoord = 'A' + i;
        }
    }

    for (int i = 5; i <= 9; i++) {
        if (votes[i] > maxAsstCoordVotes) {
            maxAsstCoordVotes = votes[i];
            electedAsstCoord = 'A' + i;
        }
    }

    printf("\n--- Elected Candidates ---\n");
    printf("Coordinator: Candidate %c with %d votes.\n", electedCoord, maxCoordVotes);
    printf("Asst. Coordinator: Candidate %c with %d votes.\n", electedAsstCoord, maxAsstCoordVotes);
}

int main() {
    int choice;

    while (1) {
        displayMainMenu();
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                castVote();
                break;
            case 2:
                viewVoteCount();
                break;
            case 3:
                displayWinners();
                break;
            case 4:
                printf("Exiting Voting Platform. Thank you.\n");
                return 0;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}
